# Proyecciones Basket · web v1

Web con las probabilidades de la Euroliga (playoffs, Final Four y título), los
partidos clave de cada jornada y la validación del modelo. Se actualiza sola
cada día con GitHub Actions y se publica gratis con GitHub Pages.

## Qué hay en cada carpeta

| Ruta | Qué es |
|---|---|
| `docs/index.html` | La web. |
| `docs/data/euroliga.json` | Los datos que muestra la web (se regeneran cada día). Al principio trae datos de demostración. |
| `modelo/euroliga_sim_v2.py` | El modelo (el mismo del cuaderno v2). |
| `actualizar_web.py` | Ejecuta el modelo y genera `docs/data/euroliga.json`. Aquí se cambia el nombre del proyecto. |
| `resultados/` | Estado guardado entre ejecuciones: historial, predicciones registradas, cuotas, etc. |
| `.github/workflows/actualizar.yml` | La actualización automática diaria. |

## Puesta en marcha (una sola vez)

1. **Crea una cuenta en GitHub** (gratis) si no tienes.
2. **Crea un repositorio nuevo**: botón «New», ponle un nombre (por ejemplo `proyecciones-basket`)
   y márcalo como **Public** (GitHub Pages es gratis en repositorios públicos).
3. **Sube los archivos**: en el repositorio, «Add file» → «Upload files» y arrastra
   todo el contenido de esta carpeta. Pulsa «Commit changes».
   - Comprueba que existe `.github/workflows/actualizar.yml`. Algunos ordenadores ocultan
     las carpetas que empiezan por punto y no se suben. Si falta: «Add file» → «Create new file»,
     escribe `.github/workflows/actualizar.yml` como nombre y pega el contenido del archivo.
4. **(Opcional) Conserva tu historial**: sube a la carpeta `resultados/` los archivos que
   ya tienes en tu Drive (`historial.csv`, `predicciones_registradas.csv`, `cuotas.csv`,
   `parametros_optimos.json`, `partidos_2024.csv`, `partidos_2025.csv`).
5. **Da permiso de escritura a las actualizaciones**: «Settings» → «Actions» → «General» →
   «Workflow permissions» → «Read and write permissions» → «Save».
6. **Lanza la primera actualización**: pestaña «Actions» → «Actualizar web» → «Run workflow».
   Tarda unos minutos. Cuando salga en verde, `docs/data/euroliga.json` ya tendrá los datos reales.
7. **Publica la web**: «Settings» → «Pages» → en «Build and deployment» elige
   «Deploy from a branch», rama `main`, carpeta `/docs` → «Save».
   En uno o dos minutos la web estará en `https://TU_USUARIO.github.io/proyecciones-basket/`.

A partir de ahí se actualiza sola cada mañana.

## Cosas que puedes cambiar

- **Nombre del proyecto**: `NOMBRE_SITIO` en `actualizar_web.py`.
- **Parámetros del modelo**: `USAR_PARAMETROS_OPTIMOS` y `VERSION_MODELO` en `actualizar_web.py`
  (ahora mismo usa los parámetros v1).
- **Cuotas de las casas de apuestas**: edita `resultados/cuotas.csv` desde la web de GitHub
  (columnas `jornada, cod_local, cod_visitante, cuota_local, cuota_visitante`), antes de cada jornada.
- **Hora de actualización**: la línea `cron` de `.github/workflows/actualizar.yml`.

## Si algo falla

- Si una actualización sale en rojo en «Actions», ábrela para ver el error.
- GitHub pausa las tareas programadas de repositorios sin actividad durante 60 días. Si pasa,
  aparece un aviso en «Actions» con un botón para reactivarlas.
- Para probar en tu ordenador: `pip install -r requirements.txt` y `python actualizar_web.py --demo`.
  Después abre la web con un servidor local: `python -m http.server -d docs` y entra en `http://localhost:8000`.
