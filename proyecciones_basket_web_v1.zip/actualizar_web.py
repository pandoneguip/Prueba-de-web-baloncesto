"""
Actualiza los datos de la web (docs/data/euroliga.json).

Ejecuta el modelo de la Euroliga, guarda el estado (historial, predicciones
registradas...) en la carpeta resultados/ y exporta todo lo que la web necesita
en un único archivo JSON. Lo lanza GitHub Actions automáticamente cada día,
pero también se puede ejecutar a mano:

    python actualizar_web.py           # datos reales
    python actualizar_web.py --demo    # liga inventada, para probar
"""

import argparse
import json
import os
import sys
from datetime import datetime, timezone

import numpy as np
import pandas as pd

RAIZ = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(RAIZ, "modelo"))
import euroliga_sim_v2 as m  # noqa: E402

# ===== CONFIGURACIÓN DE LA WEB =====
NOMBRE_SITIO = "Proyecciones Basket"   # nombre del proyecto (sale en la cabecera)
USAR_PARAMETROS_OPTIMOS = False         # False = parámetros v1 (los recomendados ahora)
VERSION_MODELO = "v1"                   # lo que la web dice sobre el modelo usado
N_SIMS = 200_000
CARPETA_RESULTADOS = os.path.join(RAIZ, "resultados")
SALIDA_JSON = os.path.join(RAIZ, "docs", "data", "euroliga.json")


def _r(x, d=4):
    """Redondeo seguro para JSON (NaN -> None)."""
    if x is None:
        return None
    try:
        if pd.isna(x):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (float, np.floating)):
        return round(float(x), d)
    return x


def _cargar_temporada(temporada, actual):
    """La temporada actual se descarga siempre; las pasadas, solo si no están ya guardadas."""
    ruta = os.path.join(CARPETA_RESULTADOS, f"partidos_{temporada}.csv")
    if not actual and os.path.exists(ruta):
        return pd.read_csv(ruta)
    return m.cargar_datos(temporada)


def _cuantiles_victorias(dist):
    cdf = np.cumsum(dist) / dist.sum()
    q = lambda p: int(np.searchsorted(cdf, p))
    return {"p05": q(.05), "p25": q(.25), "p50": q(.5), "p75": q(.75), "p95": q(.95),
            "moda": int(dist.argmax())}


def _metricas(p, y):
    if len(y) == 0:
        return None
    mt = m.metricas(p, y)
    return {k: _r(v) for k, v in mt.items()}


def _calibracion(bt):
    pf = np.maximum(bt.p_local, 1 - bt.p_local)
    yf = np.where(bt.p_local >= .5, bt.gana_local, 1 - bt.gana_local)
    bins = []
    for lo, hi in zip([.5, .6, .7, .8, .9], [.6, .7, .8, .9, 1.0001]):
        mask = (pf >= lo) & (pf < hi)
        k = int(mask.sum())
        if k < 15:
            continue
        obs = float(yf[mask].mean())
        bins.append({"desde": lo, "hasta": min(hi, 1.0), "prob_media": _r(pf[mask].mean()),
                     "observado": _r(obs), "partidos": k,
                     "error": _r(1.96 * np.sqrt(obs * (1 - obs) / k))})
    return bins


def actualizar(df, df_prev, df_prev2, cfg, rng, fecha=None):
    """Ejecuta todo el modelo y devuelve el diccionario que se exporta a la web."""
    m.comprobar_calendario(df)
    equipos = sorted(set(df.cod_local) | set(df.cod_visitante))
    n = len(equipos)
    nombres = {**dict(zip(df.cod_visitante, df.visitante)), **dict(zip(df.cod_local, df.local))}
    jug = df[df.pts_local.notna()]
    jornada = int(jug.jornada.max()) if len(jug) else 0
    partidos_por_jornada = n // 2
    jugados_jornada = int((jug.jornada == jornada).sum()) if jornada else 0

    # --- modelo
    m_prior, sd_prior, sigma = m.construir_prior(equipos, df_prev, cfg)
    media, cov, _, _ = m.ajustar_ratings(df, equipos, m_prior, sd_prior, sigma, cfg)
    pendientes = df.pts_local.isna().values
    jornada_prox = int(df.jornada[pendientes].min()) if pendientes.any() else None
    idx_clave = (np.where(pendientes & (df.jornada.values == jornada_prox))[0]
                 if jornada_prox else np.array([], int))
    print(f"Simulando {m.num(cfg['n_sims'])} temporadas...")
    acc = m.simular(df, equipos, media, cov, sigma, cfg, rng, idx_clave)
    t = m.tabla_resumen(df, equipos, nombres, media, acc, cfg)
    t.to_csv(os.path.join(CARPETA_RESULTADOS, f"resumen_j{jornada:02d}.csv"), index=False)
    m.actualizar_historial(t, jornada, cfg)

    clave = pd.DataFrame()
    if jornada_prox:
        clave = m.analizar_partidos_clave(df, idx_clave, equipos, nombres, media, cov,
                                          sigma, acc, cfg)
        m.registrar_predicciones(clave, cfg["temporada"], df)

    # --- validación
    bt = m.backtest(df, m_prior, sd_prior, sigma, cfg, cfg["temporada"])
    if df_prev is not None:
        eq_prev = sorted(set(df_prev.cod_local) | set(df_prev.cod_visitante))
        cfg_prev = dict(cfg, ajustes_prior={})
        mp, sp, sg = m.construir_prior(eq_prev, df_prev2, cfg_prev)
        bt = pd.concat([bt, m.backtest(df_prev, mp, sp, sg, cfg_prev, cfg["temporada"] - 1)],
                       ignore_index=True)
    m.validar(bt, cfg["temporada"], jornada, cfg)

    # --- exportación
    N = cfg["n_sims"]
    orden = list(t.codigo)
    equipos_json = []
    for r in t.itertuples():
        i = equipos.index(r.codigo)
        equipos_json.append({
            "codigo": r.codigo, "nombre": r.equipo, "nombre_oficial": nombres[r.codigo],
            "victorias": int(r.V), "derrotas": int(r.D), "diferencia": int(r.dif),
            "rating": _r(r.rating, 1), "ventaja_campo": _r(r.ventaja_campo, 1),
            "victorias_esperadas": _r(r.victorias_esperadas, 1),
            "rango_victorias": _cuantiles_victorias(acc["victorias"][i]),
            "posiciones": [_r(x) for x in acc["pos"][i] / N],
            "p_1o": _r(r.p_1o), "p_top6": _r(r.p_top6), "p_playin": _r(r.p_playin),
            "p_fuera": _r(r.p_fuera), "p_playoffs": _r(r.p_playoffs),
            "p_final_four": _r(r.p_final_four), "p_final": _r(r.p_final),
            "p_campeon": _r(r.p_campeon),
        })

    # victorias necesarias
    v = acc["corte_v"]
    ok = v > 1000
    necesarias = {"victorias": [], "p_top6": [], "p_top10": []}
    for w in range(len(v)):
        if ok[w]:
            necesarias["victorias"].append(w)
            necesarias["p_top6"].append(_r(acc["corte_top6"][w] / v[w]))
            necesarias["p_top10"].append(_r(acc["corte_top10"][w] / v[w]))

    # historial (para la evolución)
    ruta_h = os.path.join(CARPETA_RESULTADOS, "historial.csv")
    historial = []
    if os.path.exists(ruta_h):
        h = pd.read_csv(ruta_h)
        for r in h.itertuples():
            historial.append({"jornada": int(r.jornada), "codigo": r.codigo, "nombre": r.equipo,
                              "p_top6": _r(r.p_top6), "p_playin": _r(r.p_playin),
                              "p_final_four": _r(r.p_final_four), "p_campeon": _r(r.p_campeon)})

    # validación
    act = bt[bt.temporada == cfg["temporada"]]
    validacion = {
        "temporada_actual": _metricas(act.p_local, act.gana_local),
        "total": _metricas(bt.p_local, bt.gana_local),
        "siempre_local": {
            "acierto": _r(bt.gana_local.mean()),
            "brier": _r(m._brier(np.full(len(bt), bt.gana_local.mean()), bt.gana_local)),
        } if len(bt) else None,
        "calibracion": _calibracion(bt) if len(bt) else [],
        "mercado": None,
    }
    cuotas = m.cargar_cuotas()
    if cuotas is not None and len(act):
        comp = act.merge(cuotas, on=["cod_local", "cod_visitante"])
        if len(comp):
            validacion["mercado"] = {
                "partidos": len(comp),
                "modelo": _metricas(comp.p_local, comp.gana_local),
                "casas": _metricas(comp.p_mercado, comp.gana_local),
            }

    # predicciones registradas antes de jugarse, con su resultado
    registradas = {"resumen": None, "partidos": []}
    ruta_reg = os.path.join(CARPETA_RESULTADOS, "predicciones_registradas.csv")
    if os.path.exists(ruta_reg):
        reg = pd.read_csv(ruta_reg)
        reg = reg[reg.temporada == cfg["temporada"]]
        res = df[df.pts_local.notna()][["cod_local", "cod_visitante", "pts_local", "pts_visitante"]]
        hechos = reg.merge(res, on=["cod_local", "cod_visitante"])
        if len(hechos):
            y = (hechos.pts_local > hechos.pts_visitante).astype(int)
            registradas["resumen"] = _metricas(hechos.p_local, y)
            hechos = hechos.assign(gana_local=y).sort_values(["jornada", "p_local"],
                                                            ascending=[False, False])
            for r in hechos.head(30).itertuples():
                registradas["partidos"].append({
                    "jornada": int(r.jornada), "local": r.local, "visitante": r.visitante,
                    "p_local": _r(r.p_local), "pts_local": int(r.pts_local),
                    "pts_visitante": int(r.pts_visitante),
                    "acierto": bool((r.p_local > .5) == r.gana_local),
                    "fecha_prediccion": r.fecha_prediccion,
                })

    partidos_clave = []
    for r in clave.itertuples() if len(clave) else []:
        d = r._asdict(); d.pop("Index", None)
        partidos_clave.append({k: _r(val) for k, val in d.items()})

    return {
        "sitio": NOMBRE_SITIO,
        "competicion": "Euroliga",
        "temporada": f"{cfg['temporada']}-{str(cfg['temporada'] + 1)[2:]}",
        "actualizado": fecha or datetime.now(timezone.utc).isoformat(timespec="minutes"),
        "version_modelo": cfg.get("version", ""),
        "n_sims": N,
        "jornada": jornada,
        "jornada_completa": jugados_jornada >= partidos_por_jornada,
        "partidos_jugados_jornada": jugados_jornada,
        "partidos_por_jornada": partidos_por_jornada,
        "jornadas_totales": int(df.jornada.max()),
        "jornada_proxima": jornada_prox,
        "plazas": {"playoff": cfg["plazas_playoff"], "playin": cfg["plazas_playin"]},
        "ventaja_campo_media": _r(media[n], 1),
        "orden": orden,
        "equipos": equipos_json,
        "victorias_necesarias": necesarias,
        "partidos_clave": partidos_clave,
        "historial": historial,
        "validacion": validacion,
        "predicciones_registradas": registradas,
    }


def guardar_json(datos, ruta=SALIDA_JSON):
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, separators=(",", ":"))
    print(f"Datos de la web guardados en {ruta} ({os.path.getsize(ruta) / 1024:.0f} KB)")


def main():
    ap = argparse.ArgumentParser(description="Actualiza los datos de la web")
    ap.add_argument("--demo", action="store_true", help="Liga inventada para probar")
    ap.add_argument("--sims", type=int, default=N_SIMS)
    args = ap.parse_args()

    os.makedirs(CARPETA_RESULTADOS, exist_ok=True)
    m.CARPETA_SALIDA = CARPETA_RESULTADOS          # el modelo guarda aquí su estado
    cfg = dict(m.CONFIG, n_sims=args.sims, version=VERSION_MODELO)
    if USAR_PARAMETROS_OPTIMOS:
        cfg = m.cargar_parametros_optimos(cfg)
    rng = np.random.default_rng(cfg["semilla"])

    if args.demo:
        df, df_prev, df_prev2 = m.datos_demo(rng)
    else:
        df = _cargar_temporada(cfg["temporada"], actual=True)
        df_prev = _cargar_temporada(cfg["temporada"] - 1, actual=False)
        df_prev2 = _cargar_temporada(cfg["temporada"] - 2, actual=False)

    datos = actualizar(df, df_prev, df_prev2, cfg, rng)
    datos["demo"] = bool(args.demo)
    guardar_json(datos)


if __name__ == "__main__":
    main()
