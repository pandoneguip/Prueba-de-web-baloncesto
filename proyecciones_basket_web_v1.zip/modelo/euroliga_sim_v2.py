"""
Simulador Montecarlo de la Euroliga
===================================

Modelo:
  1) Rating bayesiano de cada equipo a partir del margen de los partidos jugados:
         margen = rating_local - rating_visitante + ventaja_campo + ruido
         ruido ~ Normal(0, sigma)
     El punto de partida (prior) sale de la temporada anterior, "regresado" hacia
     la media porque las plantillas cambian. Según se juegan partidos, pesan más
     los datos de este año.
  2) Montecarlo: en cada simulación se sortea un nivel para cada equipo (según
     la incertidumbre del rating), se juegan los partidos que faltan, se aplica
     la clasificación con desempates y se simulan Play-In, playoffs (al mejor de
     5) y Final Four.

Uso:
  python euroliga_sim.py                    # descarga datos de la API oficial
  python euroliga_sim.py --csv partidos.csv # usa un CSV propio
  python euroliga_sim.py --demo             # liga inventada para probar
"""

import argparse
import os
from datetime import datetime

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

# ---------------------------------------------------------------------------
# CONFIGURACIÓN (todo lo que se puede tocar está aquí)
# ---------------------------------------------------------------------------
CONFIG = {
    "version": "v2",
    "temporada": 2026,          # año de inicio (2026 = temporada 2026-27)
    "n_sims": 200_000,          # número de simulaciones
    "tam_lote": 20_000,         # simulaciones por lote (baja si te falta RAM)
    "sigma": 12.0,              # desviación típica del margen de un partido
    "ventaja_campo": 3.5,       # prior de la ventaja de jugar en casa (puntos)
    "sd_ventaja_campo": 1.5,
    "regresion_previa": 0.6,    # qué parte del rating del año pasado se conserva
    "sd_previa": 5.0,           # incertidumbre del prior para equipos conocidos
    "media_nuevo": -2.0,        # prior para equipos que no jugaron el año pasado
    "sd_nuevo": 6.0,
    "margen_max": 30,           # recorta palizas al ajustar (minutos de basura)
    # --- novedades v2 (la optimización elige los mejores valores) ---
    "vida_media": None,         # en jornadas: el peso de un partido se reduce a la
                                # mitad cada X jornadas. None = todos pesan igual
    "sd_hca_equipo": 0.0,       # cuánto puede variar la ventaja de campo entre
                                # equipos (0 = la misma para todos, como en v1)
    "plazas_playoff": 6,
    "plazas_playin": 10,
    "semilla": 2026,
    # Ajustes manuales al prior (en puntos), p.ej. por fichajes/bajas:
    # "ajustes_prior": {"MAD": +1.5, "BAR": -1.0}
    "ajustes_prior": {},
    # Texto que aparece al pie de los gráficos (tu nombre, usuario, web...)
    "firma": "",
    # Cuántos partidos se muestran en el gráfico de partidos clave (el CSV los tiene todos)
    "n_partidos_clave": 6,
}

# Nombres cortos: se busca la palabra clave dentro del nombre oficial
# (así sigue funcionando aunque cambie el patrocinador)
NOMBRES_CORTOS = {
    "PANATHINAIKOS": "Panathinaikos", "OLYMPIACOS": "Olympiacos",
    "FENERBAHCE": "Fenerbahçe", "HAPOEL": "Hapoel Tel Aviv",
    "VALENCIA": "Valencia Basket", "REAL MADRID": "Real Madrid",
    "ZVEZDA": "Estrella Roja", "DUBAI": "Dubai", "VIRTUS": "Virtus Bolonia",
    "BARCELONA": "Barça", "PARTIZAN": "Partizan", "ZALGIRIS": "Žalgiris",
    "BESIKTAS": "Beşiktaş", "EFES": "Anadolu Efes", "BAYERN": "Bayern",
    "MACCABI": "Maccabi Tel Aviv", "ASVEL": "ASVEL", "PARIS": "Paris",
    "MILAN": "Olimpia Milano", "BASKONIA": "Baskonia", "MONACO": "Mónaco",
}


def nombre_corto(nombre):
    n = str(nombre).upper()
    for clave, corto in NOMBRES_CORTOS.items():
        if clave in n:
            return corto
    return str(nombre).title()


def num(x):
    """200000 -> '200.000'"""
    return f"{x:,}".replace(",", ".")


def pct(x, dec=1):
    """0.255 -> '25,5%'"""
    return f"{x * 100:.{dec}f}".replace(".", ",") + "%"

# Copia de los valores por defecto (= modelo v1) para comparar en la optimización
CONFIG_V1 = dict(CONFIG)

CARPETA_SALIDA = "resultados"


# ---------------------------------------------------------------------------
# 1. DATOS
# ---------------------------------------------------------------------------
COLUMNAS = ["jornada", "cod_local", "cod_visitante", "local", "visitante",
            "pts_local", "pts_visitante"]


def _buscar_col(df, candidatas):
    for c in candidatas:
        if c in df.columns:
            return c
    return None


def descargar_temporada(temporada):
    """Descarga calendario y resultados de la API oficial (api-live.euroleague.net)
    y los devuelve en el formato estándar del script."""
    import requests
    import xmltodict

    base = "https://api-live.euroleague.net/v1"
    params = {"seasonCode": f"E{temporada}"}

    r = requests.get(f"{base}/schedules", params=params, timeout=60)
    r.raise_for_status()
    cal = pd.DataFrame(xmltodict.parse(r.text)["schedule"]["item"])

    r = requests.get(f"{base}/results", params=params, timeout=60)
    r.raise_for_status()
    games = xmltodict.parse(r.content)["results"].get("game", [])
    res = pd.DataFrame(games if isinstance(games, list) else [games])

    # Solo temporada regular
    fase = _buscar_col(cal, ["round", "phase"])
    if fase is not None and cal[fase].astype(str).str.contains("RS").any():
        cal = cal[cal[fase].astype(str).str.contains("RS")]
    cal = cal.copy()
    cal["jornada"] = cal["gameday"].astype(int)
    cal = cal[cal["jornada"] <= 38]

    df = pd.DataFrame({
        "jornada": cal["jornada"],
        "cod_local": cal["homecode"].astype(str).str.strip(),
        "cod_visitante": cal["awaycode"].astype(str).str.strip(),
        "local": cal["hometeam"].astype(str).str.strip(),
        "visitante": cal["awayteam"].astype(str).str.strip(),
    })

    # Resultados: un partido cuenta como jugado si tiene marcador
    if len(res):
        if "round" in res.columns and res["round"].astype(str).str.contains("RS").any():
            res = res[res["round"].astype(str).str.contains("RS")]
        res = res.copy()
        res["homescore"] = pd.to_numeric(res["homescore"], errors="coerce")
        res["awayscore"] = pd.to_numeric(res["awayscore"], errors="coerce")
        jugado = res["played"].astype(str).str.lower().eq("true") if "played" in res \
            else (res["homescore"] + res["awayscore"] > 0)
        res = res[jugado & (res["homescore"] + res["awayscore"] > 0)]
        res = pd.DataFrame({
            "cod_local": res["homecode"].astype(str).str.strip(),
            "cod_visitante": res["awaycode"].astype(str).str.strip(),
            "pts_local": res["homescore"],
            "pts_visitante": res["awayscore"],
        })
        df = df.merge(res, on=["cod_local", "cod_visitante"], how="left")
    else:
        df["pts_local"] = np.nan
        df["pts_visitante"] = np.nan

    return df[COLUMNAS].sort_values(["jornada", "cod_local"]).reset_index(drop=True)


def cargar_datos(temporada, csv=None):
    if csv:
        df = pd.read_csv(csv)
        faltan = set(COLUMNAS) - set(df.columns)
        if faltan:
            raise ValueError(f"Al CSV le faltan columnas: {faltan}")
        return df[COLUMNAS]
    df = descargar_temporada(temporada)
    os.makedirs(CARPETA_SALIDA, exist_ok=True)
    ruta = os.path.join(CARPETA_SALIDA, f"partidos_{temporada}.csv")
    df.to_csv(ruta, index=False)
    print(f"Datos guardados en {ruta} (puedes revisarlos o corregirlos a mano)")
    return df


def comprobar_calendario(df):
    n_eq = len(set(df.cod_local) | set(df.cod_visitante))
    esperados = n_eq * (n_eq - 1)
    if len(df) != esperados:
        print(f"AVISO: hay {len(df)} partidos y con {n_eq} equipos deberían ser "
              f"{esperados}. Revisa el CSV.")
    jugados = df.pts_local.notna().sum()
    print(f"{n_eq} equipos | {jugados} partidos jugados | "
          f"{len(df) - jugados} por jugar")


# ---------------------------------------------------------------------------
# 2. RATINGS (regresión bayesiana sobre el margen)
# ---------------------------------------------------------------------------
def _matriz_diseno(df, idx, n):
    """Columnas: n ratings | ventaja de campo general | n extras de campo por equipo."""
    h = df.cod_local.map(idx).values; a = df.cod_visitante.map(idx).values
    filas = np.arange(len(df))
    X = np.zeros((len(df), 2 * n + 1))
    X[filas, h] = 1
    X[filas, a] = -1
    X[:, n] = 1
    X[filas, n + 1 + h] = 1
    return X


def _prior_completo(media_prior, sd_prior, cfg):
    n = len(media_prior)
    sd_eq = max(cfg.get("sd_hca_equipo", 0.0), 1e-3)   # 0 = desactivado
    m0 = np.concatenate([media_prior, [cfg["ventaja_campo"]], np.zeros(n)])
    sd = np.concatenate([sd_prior, [cfg["sd_ventaja_campo"]], np.full(n, sd_eq)])
    return m0, 1 / sd ** 2


def _pesos(jornadas, jornada_ref, cfg):
    """Peso de cada partido: 1 si no hay decaimiento; si no, se reduce a la
    mitad cada 'vida_media' jornadas hacia atrás."""
    vm = cfg.get("vida_media")
    if not vm:
        return np.ones(len(jornadas))
    return 0.5 ** ((jornada_ref - np.asarray(jornadas, float)) / vm)


def _ajuste(X, y, w, m0, prec0, sigma):
    Xw = X * w[:, None]
    prec = Xw.T @ X / sigma ** 2 + np.diag(prec0)
    cov = np.linalg.inv(prec)
    media = cov @ (Xw.T @ y / sigma ** 2 + prec0 * m0)
    return media, cov


def ajustar_ratings(df, equipos, media_prior, sd_prior, sigma, cfg, jornada_ref=None):
    """Devuelve media y covarianza de [ratings (n), ventaja_campo, extra_campo_equipo (n)]."""
    idx = {e: i for i, e in enumerate(equipos)}
    n = len(equipos)
    jug = df[df.pts_local.notna()]
    X = _matriz_diseno(jug, idx, n)
    y = (jug.pts_local - jug.pts_visitante).clip(-cfg["margen_max"], cfg["margen_max"]).values
    if jornada_ref is None:
        jornada_ref = (jug.jornada.max() + 1) if len(jug) else 1
    w = _pesos(jug.jornada.values, jornada_ref, cfg)
    m0, prec0 = _prior_completo(np.asarray(media_prior, float), np.asarray(sd_prior, float), cfg)
    media, cov = _ajuste(X, y, w, m0, prec0, sigma)
    return media, cov, X, y


def ratings_temporada(df_prev, cfg):
    """Rating final de cada equipo en una temporada completa (sin decaimiento)
    y sigma estimada con sus residuos."""
    eq_prev = sorted(set(df_prev.cod_local) | set(df_prev.cod_visitante))
    c = dict(cfg, vida_media=None, sd_hca_equipo=0.0)
    m, _, X, y = ajustar_ratings(df_prev, eq_prev, np.zeros(len(eq_prev)),
                                 np.full(len(eq_prev), 10.0), cfg["sigma"], c)
    sigma = float(np.clip(np.std(y - X @ m), 10, 14))
    return dict(zip(eq_prev, m[:len(eq_prev)])), sigma


def prior_desde(equipos, prev, cfg):
    """Prior de esta temporada a partir de los ratings de la anterior (dict o None)."""
    n = len(equipos)
    if prev is None:
        return np.zeros(n), np.full(n, cfg["sd_nuevo"], dtype=float)
    medias = np.full(n, cfg["media_nuevo"], dtype=float)
    sds = np.full(n, cfg["sd_nuevo"], dtype=float)
    for i, e in enumerate(equipos):
        if e in prev:
            medias[i] = cfg["regresion_previa"] * prev[e]
            sds[i] = cfg["sd_previa"]
    for e, ajuste in cfg.get("ajustes_prior", {}).items():
        if e in equipos:
            medias[equipos.index(e)] += ajuste
    return medias - medias.mean(), sds   # la liga está centrada en 0


def construir_prior(equipos, df_prev, cfg):
    """Prior a partir de la temporada anterior. Devuelve (medias, sds, sigma)."""
    if df_prev is not None and df_prev.pts_local.notna().sum() > 50:
        prev, sigma = ratings_temporada(df_prev, cfg)
        print(f"Prior construido con la temporada anterior (sigma estimada = {sigma:.1f})")
    else:
        prev, sigma = None, cfg["sigma"]
        print("Sin temporada anterior: todos los equipos empiezan iguales")
    medias, sds = prior_desde(equipos, prev, cfg)
    return medias, sds, sigma


# ---------------------------------------------------------------------------
# 3. SIMULACIÓN
# ---------------------------------------------------------------------------
def margen_simulado(rng, mu, sigma):
    """Margen entero; si sale 0 hay prórroga y alguien gana por 1-6 puntos."""
    cont = mu + sigma * rng.standard_normal(mu.shape)
    m = np.rint(cont)
    empate = m == 0
    m[empate] = np.sign(cont[empate] + 1e-9) * rng.integers(1, 7, empate.sum())
    return m


def gana_a(rng, R, V, a, b, sigma, en_casa_a):
    """¿Gana el equipo a (índices por simulación) al b? en_casa_a: 1, 0 (neutral) o -1.
    V[s, e] = ventaja de campo del equipo e cuando juega en casa."""
    s = np.arange(R.shape[0])
    mu = R[s, a] - R[s, b]
    if en_casa_a == 1:
        mu = mu + V[s, a]
    elif en_casa_a == -1:
        mu = mu - V[s, b]
    return mu + sigma * rng.standard_normal(len(s)) > 0


def serie_al_mejor_de_5(rng, R, V, alto, bajo, sigma):
    """Formato 2-2-1: partidos 1, 2 y 5 en casa del mejor clasificado.
    Jugar los 5 y quedarse con la mayoría equivale a parar al llegar a 3."""
    casa = [1, 1, -1, -1, 1]
    victorias = sum(gana_a(rng, R, V, alto, bajo, sigma, c).astype(int) for c in casa)
    return np.where(victorias >= 3, alto, bajo)


def simular(df, equipos, media, cov, sigma, cfg, rng, idx_clave=()):
    """idx_clave: posiciones (en df) de los partidos de la próxima jornada,
    para medir cuánto cambia cada equipo según quién gane cada uno."""
    n = len(equipos)
    idx = {e: i for i, e in enumerate(equipos)}
    h = df.cod_local.map(idx).values
    a = df.cod_visitante.map(idx).values
    jugado = df.pts_local.notna().values
    margen_real = (df.pts_local - df.pts_visitante).fillna(0).values
    G = len(df)

    # Matrices one-hot para contar victorias y cara a cara con productos matriciales
    OH = np.zeros((G, n), np.float32); OH[np.arange(G), h] = 1
    OA = np.zeros((G, n), np.float32); OA[np.arange(G), a] = 1
    PHA = np.zeros((G, n * n), np.float32); PHA[np.arange(G), h * n + a] = 1
    PAH = np.zeros((G, n * n), np.float32); PAH[np.arange(G), a * n + h] = 1

    max_v = 2 * (n - 1)
    acc = {
        "pos": np.zeros((n, n)),
        "victorias": np.zeros((n, max_v + 1)),
        "playoffs": np.zeros(n), "final_four": np.zeros(n),
        "final": np.zeros(n), "campeon": np.zeros(n),
        "corte_v": np.zeros(max_v + 1), "corte_top6": np.zeros(max_v + 1),
        "corte_top10": np.zeros(max_v + 1),
        # partidos clave: P(top6 / top10 | gana el local de cada partido)
        "clave_n_local": np.zeros(len(idx_clave)),
        "clave_top6_local": np.zeros((len(idx_clave), n)),
        "clave_top10_local": np.zeros((len(idx_clave), n)),
        "top6_total": np.zeros(n), "top10_total": np.zeros(n),
    }
    idx_clave = np.asarray(idx_clave, dtype=int)

    L = np.linalg.cholesky(cov + 1e-9 * np.eye(len(media)))
    hechas = 0
    while hechas < cfg["n_sims"]:
        S = min(cfg["tam_lote"], cfg["n_sims"] - hechas)
        P = media + rng.standard_normal((S, len(media))) @ L.T
        R = P[:, :n]
        V = P[:, n][:, None] + P[:, n + 1:]          # ventaja de campo de cada equipo

        # --- temporada regular
        M = np.tile(margen_real, (S, 1))
        mu = R[:, h[~jugado]] - R[:, a[~jugado]] + V[:, h[~jugado]]
        M[:, ~jugado] = margen_simulado(rng, mu, sigma)
        M = M.astype(np.float32)
        gl = (M > 0).astype(np.float32)

        V = gl @ OH + (1 - gl) @ OA                       # victorias
        DIF = M @ OH - M @ OA                             # diferencia de puntos
        H2H = (gl @ PHA + (1 - gl) @ PAH).reshape(S, n, n)  # victorias i contra j
        D2H = (M @ PHA - M @ PAH).reshape(S, n, n)          # diferencia i contra j

        # --- desempates (normativa Euroliga, versión simplificada):
        #     victorias > cara a cara entre empatados > diferencia en esos
        #     partidos > diferencia general > sorteo
        mismo = V[:, :, None] == V[:, None, :]
        v2 = (H2H * mismo).sum(2)
        d2 = (D2H * mismo).sum(2)
        clave = (((V.astype(np.int64) * 100 + v2.astype(np.int64)) * 10_000
                  + (d2.astype(np.int64) + 5_000)) * 10_000
                 + (DIF.astype(np.int64) + 5_000)) * 1_000 \
            + rng.integers(0, 1_000, (S, n))
        orden = np.argsort(-clave, axis=1)                # orden[s, k] = equipo en puesto k
        pos = np.empty_like(orden)
        np.put_along_axis(pos, orden, np.arange(n)[None, :].repeat(S, 0), axis=1)

        Vi = V.astype(int)
        for e in range(n):
            acc["pos"][e] += np.bincount(pos[:, e], minlength=n)
            acc["victorias"][e] += np.bincount(Vi[:, e], minlength=max_v + 1)
        np.add.at(acc["corte_v"], Vi.ravel(), 1)
        np.add.at(acc["corte_top6"], Vi.ravel(), (pos < cfg["plazas_playoff"]).ravel())
        np.add.at(acc["corte_top10"], Vi.ravel(), (pos < cfg["plazas_playin"]).ravel())

        # --- partidos clave
        top6 = (pos < cfg["plazas_playoff"]).astype(np.float32)
        top10 = (pos < cfg["plazas_playin"]).astype(np.float32)
        acc["top6_total"] += top6.sum(0)
        acc["top10_total"] += top10.sum(0)
        if len(idx_clave):
            Wk = gl[:, idx_clave]
            acc["clave_n_local"] += Wk.sum(0)
            acc["clave_top6_local"] += Wk.T @ top6
            acc["clave_top10_local"] += Wk.T @ top10

        # --- Play-In: 7v8 (el ganador es 7.º), 9v10, y perdedor 7v8 vs ganador 9v10
        s7, s8, s9, s10 = orden[:, 6], orden[:, 7], orden[:, 8], orden[:, 9]
        g78 = gana_a(rng, R, V, s7, s8, sigma, 1)
        sem7 = np.where(g78, s7, s8); perd78 = np.where(g78, s8, s7)
        g910 = gana_a(rng, R, V, s9, s10, sigma, 1)
        gan910 = np.where(g910, s9, s10)
        gfin = gana_a(rng, R, V, perd78, gan910, sigma, 1)
        sem8 = np.where(gfin, perd78, gan910)

        sembrados = np.column_stack([orden[:, :6], sem7, sem8])
        for k in range(8):
            acc["playoffs"] += np.bincount(sembrados[:, k], minlength=n)

        # --- Playoffs al mejor de 5: 1v8, 4v5, 2v7, 3v6
        sp = lambda i, j: serie_al_mejor_de_5(rng, R, V, sembrados[:, i],
                                              sembrados[:, j], sigma)
        f1, f2, f3, f4 = sp(0, 7), sp(3, 4), sp(1, 6), sp(2, 5)
        for f in (f1, f2, f3, f4):
            acc["final_four"] += np.bincount(f, minlength=n)

        # --- Final Four en pista neutral
        fa = np.where(gana_a(rng, R, V, f1, f2, sigma, 0), f1, f2)
        fb = np.where(gana_a(rng, R, V, f3, f4, sigma, 0), f3, f4)
        acc["final"] += np.bincount(fa, minlength=n) + np.bincount(fb, minlength=n)
        campeon = np.where(gana_a(rng, R, V, fa, fb, sigma, 0), fa, fb)
        acc["campeon"] += np.bincount(campeon, minlength=n)

        hechas += S
        print(f"  {num(hechas)} / {num(cfg['n_sims'])} simulaciones", end="\r")
    print()
    return acc


# ---------------------------------------------------------------------------
# 4. RESULTADOS Y GRÁFICOS
# ---------------------------------------------------------------------------
def clasificacion_actual(df, equipos):
    jug = df[df.pts_local.notna()]
    v = {e: 0 for e in equipos}; d = {e: 0 for e in equipos}
    for r in jug.itertuples():
        gana_local = r.pts_local > r.pts_visitante
        v[r.cod_local if gana_local else r.cod_visitante] += 1
        d[r.cod_local] += r.pts_local - r.pts_visitante
        d[r.cod_visitante] += r.pts_visitante - r.pts_local
    pj = {e: ((jug.cod_local == e) | (jug.cod_visitante == e)).sum() for e in equipos}
    return v, d, pj


def tabla_resumen(df, equipos, nombres, media, acc, cfg):
    N = cfg["n_sims"]
    v, d, pj = clasificacion_actual(df, equipos)
    pos = acc["pos"] / N
    vict = acc["victorias"]
    xs = np.arange(vict.shape[1])
    t = pd.DataFrame({
        "codigo": equipos,
        "equipo": [nombre_corto(nombres[e]) for e in equipos],
        "V": [v[e] for e in equipos],
        "D": [pj[e] - v[e] for e in equipos],
        "dif": [int(d[e]) for e in equipos],
        "rating": np.round(media[:len(equipos)], 1),
        "ventaja_campo": np.round(media[len(equipos)] + media[len(equipos) + 1:], 1),
        "victorias_esperadas": np.round((vict * xs).sum(1) / N, 1),
        "victorias_mas_probables": vict.argmax(1),
        "p_1o": pos[:, 0],
        "p_top6": pos[:, :cfg["plazas_playoff"]].sum(1),
        "p_playin": pos[:, cfg["plazas_playoff"]:cfg["plazas_playin"]].sum(1),
        "p_fuera": pos[:, cfg["plazas_playin"]:].sum(1),
        "p_playoffs": acc["playoffs"] / N,
        "p_final_four": acc["final_four"] / N,
        "p_final": acc["final"] / N,
        "p_campeon": acc["campeon"] / N,
    })
    return t.sort_values(["victorias_esperadas", "p_top6"], ascending=False)\
            .reset_index(drop=True)


def _guardar(fig, nombre, cfg=CONFIG):
    pie = (f"Datos: API oficial Euroliga · Modelo {cfg.get('version', '')}: rating bayesiano + "
           f"{num(cfg['n_sims'])} simulaciones Montecarlo")
    if cfg.get("firma"):
        pie += f" · {cfg['firma']}"
    fig.text(0.99, -0.01, pie, ha="right", va="top", fontsize=8, color="#868e96")
    ruta = os.path.join(CARPETA_SALIDA, nombre)
    fig.savefig(ruta, dpi=200, bbox_inches="tight")
    plt.close(fig)
    return ruta


def grafico_mapa_posiciones(t, equipos, acc, cfg, jornada):
    n = len(equipos)
    orden = [equipos.index(c) for c in t.codigo]
    P = acc["pos"][orden] / cfg["n_sims"] * 100
    cmap = LinearSegmentedColormap.from_list("eu", ["#ffffff", "#ffd8a8", "#f76707", "#7a1f00"])

    fig, ax = plt.subplots(figsize=(13, 9))
    ax.imshow(P, cmap=cmap, aspect="auto", vmin=0, vmax=max(40, P.max()))
    for i in range(n):
        for j in range(n):
            if P[i, j] >= 0.5:
                ax.text(j, i, f"{P[i, j]:.0f}", ha="center", va="center", fontsize=7.5,
                        color="white" if P[i, j] > 25 else "#333")
    for x, lab in [(cfg["plazas_playoff"] - .5, "Playoffs"),
                   (cfg["plazas_playin"] - .5, "Play-In")]:
        ax.axvline(x, color="#222", lw=1.2, ls="--")
    ax.set_xticks(range(n), [f"{k + 1}º" for k in range(n)], fontsize=8)
    ax.set_yticks(range(n), [f"{e}  ({v}-{d})" for e, v, d in zip(t.equipo, t.V, t.D)],
                  fontsize=9)
    ax.xaxis.tick_top()
    ax.set_title(f"Euroliga {cfg['temporada']}-{str(cfg['temporada'] + 1)[2:]} · "
                 f"Probabilidad (%) de acabar en cada posición\n"
                 f"Tras la jornada {jornada} · {num(cfg['n_sims'])} simulaciones",
                 fontsize=13, pad=30)
    return _guardar(fig, f"mapa_posiciones_j{jornada:02d}.png", cfg)


def grafico_destinos(t, cfg, jornada):
    t = t.sort_values(["p_top6", "p_playin"], ascending=True)
    fig, ax = plt.subplots(figsize=(10, 8))
    y = np.arange(len(t))
    capas = [("p_top6", "Top 6 (playoffs directos)", "#1c7ed6"),
             ("p_playin", "7º-10º (Play-In)", "#fab005"),
             ("p_fuera", "Eliminado", "#ced4da")]
    izq = np.zeros(len(t))
    for col, lab, color in capas:
        vals = t[col].values * 100
        ax.barh(y, vals, left=izq, color=color, label=lab, height=.75)
        for yi, (l, w) in enumerate(zip(izq, vals)):
            if w >= 7:
                ax.text(l + w / 2, yi, f"{w:.0f}%", ha="center", va="center", fontsize=8)
        izq += vals
    ax.set_yticks(y, t.equipo, fontsize=9)
    ax.set_xlim(0, 100); ax.set_xlabel("%")
    ax.legend(loc="lower center", bbox_to_anchor=(.5, 1.0), ncol=3, frameon=False)
    ax.set_title(f"¿Dónde acaba cada equipo? · Jornada {jornada}", pad=30)
    ax.spines[["top", "right"]].set_visible(False)
    return _guardar(fig, f"destinos_j{jornada:02d}.png", cfg)


def grafico_victorias(t, equipos, acc, jornada, cfg=CONFIG):
    """Rango de victorias finales: 90% central, 50% central y valor más probable."""
    fig, ax = plt.subplots(figsize=(10, 8))
    t = t.iloc[::-1]
    for yi, c in enumerate(t.codigo):
        dist = acc["victorias"][equipos.index(c)]
        cdf = np.cumsum(dist) / dist.sum()
        q = lambda p: int(np.searchsorted(cdf, p))
        ax.plot([q(.05), q(.95)], [yi, yi], color="#adb5bd", lw=2)
        ax.plot([q(.25), q(.75)], [yi, yi], color="#1c7ed6", lw=6, solid_capstyle="round")
        ax.plot(dist.argmax(), yi, "o", color="#f76707", ms=7, zorder=3)
        ax.plot(t.V.iloc[yi], yi, "|", color="#222", ms=12, mew=2)
    ax.set_yticks(range(len(t)), t.equipo, fontsize=9)
    ax.set_xlabel("Victorias al final de la temporada regular (38 partidos)")
    ax.grid(axis="x", alpha=.3)
    ax.set_title(f"Victorias proyectadas · Jornada {jornada}\n"
                 "gris: 90% de escenarios · azul: 50% · naranja: más probable · "
                 "| : victorias actuales", fontsize=11)
    ax.spines[["top", "right"]].set_visible(False)
    return _guardar(fig, f"victorias_j{jornada:02d}.png", cfg)


def grafico_campeon(t, jornada, cfg=CONFIG):
    t = t[t.p_final_four >= 0.005].sort_values("p_final_four")
    fig, ax = plt.subplots(figsize=(9, max(4, .4 * len(t))))
    y = np.arange(len(t))
    ax.barh(y, t.p_final_four * 100, color="#ffd8a8", label="Final Four")
    ax.barh(y, t.p_campeon * 100, color="#f76707", label="Campeón")
    for yi, (ff, c) in enumerate(zip(t.p_final_four, t.p_campeon)):
        ax.text(ff * 100 + .5, yi, f"{pct(c)} título", va="center", fontsize=8)
    ax.set_yticks(y, t.equipo, fontsize=9)
    ax.set_xlabel("%"); ax.legend(frameon=False, loc="lower right")
    ax.set_title(f"Probabilidad de Final Four y de título · Jornada {jornada}")
    ax.spines[["top", "right"]].set_visible(False)
    return _guardar(fig, f"campeon_j{jornada:02d}.png", cfg)


def curiosidad_victorias(acc, cfg):
    """¿Con cuántas victorias estás 'salvado'? P(top6 | V) y P(top10 | V)."""
    v = acc["corte_v"]; ok = v > 1000
    p6 = np.where(ok, acc["corte_top6"] / np.maximum(v, 1), np.nan)
    p10 = np.where(ok, acc["corte_top10"] / np.maximum(v, 1), np.nan)
    t = pd.DataFrame({"victorias": np.arange(len(v)), "p_top6": p6,
                      "p_top10": p10}).dropna()
    print("\n¿Cuántas victorias hacen falta? (según las simulaciones)")
    for col, txt in [("p_top6", "top 6"), ("p_top10", "Play-In (top 10)")]:
        for umbral in (.5, .95, .999):
            fila = t[t[col] >= umbral]
            if len(fila):
                print(f"  {txt}: con {fila.victorias.iloc[0]} victorias -> "
                      f"{pct(fila[col].iloc[0])} (umbral {pct(umbral, 1 if umbral > .99 else 0)})")
    t.to_csv(os.path.join(CARPETA_SALIDA, "victorias_necesarias.csv"), index=False)


def actualizar_historial(t, jornada, cfg=CONFIG):
    ruta = os.path.join(CARPETA_SALIDA, "historial.csv")
    nuevo = t[["codigo", "equipo", "p_top6", "p_playin", "p_final_four", "p_campeon"]].copy()
    nuevo.insert(0, "jornada", jornada)
    nuevo.insert(1, "fecha", datetime.now().strftime("%Y-%m-%d"))
    nuevo["version"] = cfg.get("version", "")
    if os.path.exists(ruta):
        h = pd.read_csv(ruta)
        h = pd.concat([h[h.jornada != jornada], nuevo])
    else:
        h = nuevo
    h.to_csv(ruta, index=False)

    if h.jornada.nunique() < 2:
        return None
    fig, ax = plt.subplots(figsize=(11, 6))
    ult = h[h.jornada == h.jornada.max()].sort_values("p_top6", ascending=False)
    cmap = plt.get_cmap("tab20")
    for k, c in enumerate(ult.codigo):
        s = h[h.codigo == c].sort_values("jornada")
        ax.plot(s.jornada, s.p_top6 * 100, "-o", ms=3, lw=1.5, color=cmap(k % 20))
        ax.text(s.jornada.iloc[-1] + .2, s.p_top6.iloc[-1] * 100, s.equipo.iloc[-1],
                fontsize=7, va="center", color=cmap(k % 20))
    ax.set_xlabel("Jornada"); ax.set_ylabel("% de acabar en el top 6")
    ax.set_title("Evolución de la probabilidad de playoffs directos")
    ax.spines[["top", "right"]].set_visible(False)
    return _guardar(fig, "evolucion_top6.png", cfg)


# ---------------------------------------------------------------------------
# 5. MODO DEMO (liga inventada para probar el script sin conexión)
# ---------------------------------------------------------------------------
def calendario_doble_vuelta(equipos, rng):
    eq = list(equipos); rng.shuffle(eq)
    n = len(eq); partidos = []
    for r in range(n - 1):
        for i in range(n // 2):
            a, b = eq[i], eq[n - 1 - i]
            if (r + i) % 2: a, b = b, a
            partidos.append((r + 1, a, b))
            partidos.append((r + n, b, a))
        eq = [eq[0]] + [eq[-1]] + eq[1:-1]
    return partidos


def liga_demo(rng, jornadas_jugadas, nivel, nombres):
    filas = []
    for j, l, v in calendario_doble_vuelta(list(nivel), rng):
        fila = [j, l, v, nombres[l], nombres[v], np.nan, np.nan]
        if j <= jornadas_jugadas:
            m = margen_simulado(rng, np.array([nivel[l] - nivel[v] + 3.5]), 12)[0]
            base = rng.normal(80, 6)
            fila[5], fila[6] = round(base + m / 2 + .1), round(base - m / 2 - .1)
            if fila[5] == fila[6]: fila[5] += 1
        filas.append(fila)
    return pd.DataFrame(filas, columns=COLUMNAS)


def datos_demo(rng):
    nombres = {f"T{k:02d}": f"Equipo {chr(65 + k)}" for k in range(20)}
    nivel = dict(zip(nombres, rng.normal(0, 5, 20)))
    nivel_prev = {k: v + rng.normal(0, 3) for k, v in nivel.items()}
    prev2 = liga_demo(rng, 38, {k: v + rng.normal(0, 3) for k, v in nivel_prev.items()}, nombres)
    prev = liga_demo(rng, 38, nivel_prev, nombres)
    act = liga_demo(rng, 8, nivel, nombres)
    return act, prev, prev2


# ---------------------------------------------------------------------------
# 6. VALIDACIÓN Y PARTIDOS CLAVE
# ---------------------------------------------------------------------------
from math import erf, sqrt

_Phi = np.vectorize(lambda x: 0.5 * (1 + erf(x / sqrt(2))))


def predecir(media, cov, sigma, ih, ia):
    """Probabilidad de victoria local y margen esperado (con la incertidumbre del rating)."""
    ih, ia = np.atleast_1d(ih), np.atleast_1d(ia)
    n = (len(media) - 1) // 2
    Xp = np.zeros((len(ih), len(media)))
    f = np.arange(len(ih))
    Xp[f, ih] = 1; Xp[f, ia] = -1; Xp[:, n] = 1; Xp[f, n + 1 + ih] = 1
    mu = Xp @ media
    var = np.einsum("ij,jk,ik->i", Xp, cov, Xp)
    return _Phi(mu / np.sqrt(sigma ** 2 + var)), mu


def _arrays_temporada(df):
    """Prepara una temporada para backtests rápidos (solo numpy)."""
    equipos = sorted(set(df.cod_local) | set(df.cod_visitante))
    idx = {e: i for i, e in enumerate(equipos)}
    jug = df[df.pts_local.notna()].reset_index(drop=True)
    return {"equipos": equipos, "jug": jug,
            "X": _matriz_diseno(jug, idx, len(equipos)),
            "margen": (jug.pts_local - jug.pts_visitante).values.astype(float),
            "jornada": jug.jornada.values}


def _predicciones_backtest(A, m_prior, sd_prior, sigma, cfg):
    """Para cada jornada k, ajusta con las jornadas < k y predice la k."""
    X, j = A["X"], A["jornada"]
    y = np.clip(A["margen"], -cfg["margen_max"], cfg["margen_max"])
    m0, prec0 = _prior_completo(np.asarray(m_prior, float), np.asarray(sd_prior, float), cfg)
    p = np.empty(len(j)); mu = np.empty(len(j))
    for k in np.unique(j):
        tr, te = j < k, j == k
        media, cov = _ajuste(X[tr], y[tr], _pesos(j[tr], k, cfg), m0, prec0, sigma)
        Xt = X[te]
        mu[te] = Xt @ media
        var = np.einsum("ij,jk,ik->i", Xt, cov, Xt)
        p[te] = _Phi(mu[te] / np.sqrt(sigma ** 2 + var))
    return p, mu


def backtest(df, m_prior, sd_prior, sigma, cfg, temporada):
    """Para cada jornada jugada, entrena SOLO con las jornadas anteriores y
    predice esa jornada. Así se mide el modelo como si lo hubieras usado en vivo."""
    A = _arrays_temporada(df)
    if len(A["jug"]) == 0:
        return pd.DataFrame()
    p, mu = _predicciones_backtest(A, m_prior, sd_prior, sigma, cfg)
    jug = A["jug"]
    return pd.DataFrame({
        "temporada": temporada, "jornada": jug.jornada.values,
        "cod_local": jug.cod_local.values, "cod_visitante": jug.cod_visitante.values,
        "local": jug.local.values, "visitante": jug.visitante.values,
        "p_local": p, "margen_esperado": mu, "margen_real": A["margen"],
        "gana_local": (A["margen"] > 0).astype(int),
    })


def cargar_cuotas():
    """Lee resultados/cuotas.csv (si existe) y lo convierte en probabilidades
    implícitas, quitando el margen de la casa."""
    ruta = os.path.join(CARPETA_SALIDA, "cuotas.csv")
    if not os.path.exists(ruta):
        return None
    c = pd.read_csv(ruta).dropna(subset=["cuota_local", "cuota_visitante"])
    if c.empty:
        return None
    il, iv = 1 / c.cuota_local, 1 / c.cuota_visitante
    c["p_mercado"] = il / (il + iv)
    return c[["cod_local", "cod_visitante", "p_mercado"]]


def metricas(p, y):
    p = np.clip(np.asarray(p, float), 1e-6, 1 - 1e-6); y = np.asarray(y)
    return {
        "partidos": len(y),
        "acierto": np.mean((p > .5) == y),
        "brier": np.mean((p - y) ** 2),
        "log_loss": -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)),
    }


def validar(bt, temporada, jornada, cfg=CONFIG):
    """Métricas, calibración y comparación con el mercado. Devuelve la ruta del gráfico."""
    if bt.empty:
        print("Todavía no hay partidos para validar")
        return None
    bt.to_csv(os.path.join(CARPETA_SALIDA, "backtest.csv"), index=False)
    act = bt[bt.temporada == temporada]

    print("\nVALIDACIÓN (cada jornada predicha solo con lo anterior)")
    print(f"  {'':28s}{'partidos':>9s}{'acierto':>9s}{'Brier':>8s}")
    lineas = [("Temporada actual", act), ("Todo (incl. temporada pasada)", bt)]
    for nombre, d in lineas:
        if len(d):
            m = metricas(d.p_local, d.gana_local)
            brier = f"{m['brier']:.3f}".replace(".", ",")
            print(f"  {nombre:28s}{m['partidos']:>9d}{pct(m['acierto']):>9s}{brier:>8s}")
    tasa_local = bt.gana_local.mean()
    print(f"  Referencias: moneda al aire -> Brier 0,250 · "
          f"'siempre gana el local' -> acierto {pct(tasa_local)}")
    print("  (Brier: error cuadrático de la probabilidad; cuanto más bajo, mejor)")

    cuotas = cargar_cuotas()
    comp = None
    if cuotas is not None:
        comp = act.merge(cuotas, on=["cod_local", "cod_visitante"])  # cuotas = temporada actual
        if len(comp):
            mm = metricas(comp.p_local, comp.gana_local)
            mk = metricas(comp.p_mercado, comp.gana_local)
            print(f"  Contra el mercado ({len(comp)} partidos con cuotas): Brier modelo "
                  f"{mm['brier']:.3f} vs casas {mk['brier']:.3f}".replace(".", ","))

    # --- gráfico: calibración + Brier comparado
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5.5),
                                   gridspec_kw={"width_ratios": [1.3, 1]})
    pf = np.maximum(bt.p_local, 1 - bt.p_local)              # prob. del favorito
    yf = np.where(bt.p_local >= .5, bt.gana_local, 1 - bt.gana_local)
    bordes = [.5, .6, .7, .8, .9, 1.0001]
    ax1.plot([.5, 1], [.5, 1], "--", color="#adb5bd", lw=1, label="Calibración perfecta")
    for lo, hi in zip(bordes[:-1], bordes[1:]):
        m = (pf >= lo) & (pf < hi)
        k = int(m.sum())
        if k < 15:          # con pocos partidos el punto no dice nada
            continue
        x, obs = pf[m].mean(), yf[m].mean()
        err = 1.96 * np.sqrt(obs * (1 - obs) / k)
        ax1.errorbar(x, obs, yerr=err, fmt="o", color="#f76707", ms=4 + np.sqrt(k),
                     capsize=3, lw=1.2)
        ax1.annotate(f"{k} partidos", (x, obs), xytext=(8, -14),
                     textcoords="offset points", fontsize=8, color="#495057")
    ax1.set_xlim(.48, 1.02); ax1.set_ylim(.3, 1.05)
    ax1.set_xlabel("Probabilidad que el modelo daba al favorito")
    ax1.set_ylabel("Veces que ganó el favorito")
    ticks = [.5, .6, .7, .8, .9, 1]
    ax1.set_xticks(ticks, [pct(t, 0) for t in ticks])
    ax1.set_yticks([.3, .4] + ticks, [pct(t, 0) for t in [.3, .4] + ticks])
    ax1.legend(frameon=False, loc="upper left")
    ax1.set_title("¿Acierta cuando dice que acierta?")

    m_all = metricas(bt.p_local, bt.gana_local)
    tasa = bt.gana_local.mean()
    b_local = _brier(np.full(len(bt), tasa), bt.gana_local)
    mejora = lambda b: (1 - b / .25) * 100
    barras = [(f"Siempre gana el local\n({pct(tasa, 0)})", mejora(b_local), "#ced4da"),
              (f"Modelo {cfg.get('version', '')}\n({m_all['partidos']} partidos)",
               mejora(m_all["brier"]), "#f76707")]
    if comp is not None and len(comp):
        barras.append((f"Modelo\n({len(comp)} con cuotas)", mejora(mm["brier"]), "#ffa94d"))
        barras.append((f"Casas de apuestas\n({len(comp)} partidos)", mejora(mk["brier"]), "#1c7ed6"))
    for i, (lab, v, col) in enumerate(barras):
        ax2.bar(i, v, color=col, width=.6)
        ax2.text(i, v + .2, f"{v:.1f}%".replace(".", ","), ha="center", fontsize=10,
                 fontweight="bold")
    ax2.set_xticks(range(len(barras)), [b[0] for b in barras], fontsize=8.5)
    ax2.set_ylabel("Error menos que una moneda al aire (%)\nmás alto = mejor")
    ax2.set_ylim(0, max(b[1] for b in barras) * 1.25 + 1)
    ax2.axhline(0, color="#495057", lw=.8)
    ax2.set_title(f"Acierto del favorito: modelo {pct(m_all['acierto'])} · "
                  f"siempre local {pct(tasa)}", fontsize=10.5)
    for ax in (ax1, ax2):
        ax.spines[["top", "right"]].set_visible(False)
    fig.suptitle("Validación del modelo · cada jornada predicha solo con datos previos",
                 fontsize=13, y=1.02)
    return _guardar(fig, f"validacion_j{jornada:02d}.png", cfg)


def registrar_predicciones(df_prox, temporada, df):
    """Guarda las predicciones de la próxima jornada ANTES de que se juegue
    (prueba pública) y cuenta cómo van las ya registradas."""
    ruta = os.path.join(CARPETA_SALIDA, "predicciones_registradas.csv")
    nuevo = df_prox[["jornada", "cod_local", "cod_visitante", "local", "visitante",
                     "p_local", "margen_esperado"]].copy()
    nuevo.insert(0, "temporada", temporada)
    nuevo.insert(1, "fecha_prediccion", datetime.now().strftime("%Y-%m-%d %H:%M"))
    clave = ["temporada", "cod_local", "cod_visitante"]
    if os.path.exists(ruta):
        reg = pd.read_csv(ruta)
        # solo se sustituyen las de partidos aún no jugados (las jugadas quedan congeladas)
        reg = reg.merge(nuevo[clave], on=clave, how="left", indicator=True)
        reg = pd.concat([reg[reg._merge == "left_only"].drop(columns="_merge"), nuevo])
    else:
        reg = nuevo
    reg.to_csv(ruta, index=False)

    jugados = reg.merge(df[df.pts_local.notna()][["cod_local", "cod_visitante",
                                                  "pts_local", "pts_visitante"]],
                        on=["cod_local", "cod_visitante"])
    jugados = jugados[jugados.temporada == temporada]
    if len(jugados):
        m = metricas(jugados.p_local, (jugados.pts_local > jugados.pts_visitante).astype(int))
        print(f"\nPredicciones registradas ya jugadas: {m['partidos']} · acierto "
              f"{pct(m['acierto'])} · Brier " + f"{m['brier']:.3f}".replace(".", ","))
    return ruta


def plantilla_cuotas(df_prox, jornada_prox):
    """Plantilla para apuntar las cuotas de la próxima jornada antes de que se juegue."""
    ruta = os.path.join(CARPETA_SALIDA, f"cuotas_plantilla_j{jornada_prox:02d}.csv")
    p = df_prox[["jornada", "cod_local", "cod_visitante", "local", "visitante"]].copy()
    p["cuota_local"] = ""; p["cuota_visitante"] = ""
    p.to_csv(ruta, index=False)
    return ruta


def analizar_partidos_clave(df, idx_clave, equipos, nombres, media, cov, sigma, acc, cfg):
    """Para cada partido de la próxima jornada: cómo queda cada equipo si gana o si pierde."""
    if len(idx_clave) == 0:
        return pd.DataFrame()
    N = cfg["n_sims"]
    ix = {e: i for i, e in enumerate(equipos)}
    prox = df.iloc[idx_clave]
    p, mu = predecir(media, cov, sigma, prox.cod_local.map(ix).values,
                     prox.cod_visitante.map(ix).values)
    filas = []
    for g, (fila, pl, m) in enumerate(zip(prox.itertuples(), p, mu)):
        nl = acc["clave_n_local"][g]
        res = {}
        for met in ("top6", "top10"):
            si_l = acc[f"clave_{met}_local"][g] / max(nl, 1)                      # gana local
            si_v = (acc[f"{met}_total"] - acc[f"clave_{met}_local"][g]) / max(N - nl, 1)
            res[met] = (si_l, si_v)
        h, a = ix[fila.cod_local], ix[fila.cod_visitante]
        dl, dv = res["top6"]
        # tercer equipo al que más le afecta este resultado
        delta = np.abs(dl - dv); delta[[h, a]] = 0
        t3 = int(delta.argmax())
        filas.append({
            "jornada": fila.jornada,
            "cod_local": fila.cod_local, "cod_visitante": fila.cod_visitante,
            "local": nombre_corto(nombres[fila.cod_local]),
            "visitante": nombre_corto(nombres[fila.cod_visitante]),
            "p_local": pl, "margen_esperado": m,
            "top6_local_actual": acc["top6_total"][h] / N,
            "top6_local_si_gana": dl[h], "top6_local_si_pierde": dv[h],
            "top6_visit_actual": acc["top6_total"][a] / N,
            "top6_visit_si_gana": dv[a], "top6_visit_si_pierde": dl[a],
            "top10_local_si_gana": res["top10"][0][h], "top10_local_si_pierde": res["top10"][1][h],
            "top10_visit_si_gana": res["top10"][1][a], "top10_visit_si_pierde": res["top10"][0][a],
            "tercero_mas_afectado": nombre_corto(nombres[equipos[t3]]),
            "tercero_le_conviene": nombre_corto(nombres[fila.cod_local if dl[t3] > dv[t3]
                                                        else fila.cod_visitante]),
            "tercero_delta_top6": delta[t3],
        })
    c = pd.DataFrame(filas)
    c["importancia"] = ((c.top6_local_si_gana - c.top6_local_si_pierde)
                        + (c.top6_visit_si_gana - c.top6_visit_si_pierde)
                        + (c.top10_local_si_gana - c.top10_local_si_pierde)
                        + (c.top10_visit_si_gana - c.top10_visit_si_pierde))
    c = c.sort_values("importancia", ascending=False).reset_index(drop=True)

    print(f"\nPARTIDOS CLAVE DE LA JORNADA {int(c.jornada.min())}")
    for r in c.itertuples():
        print(f"  {r.local} vs {r.visitante}  (local {pct(r.p_local, 0)})")
        print(f"     {r.local}: top 6 {pct(r.top6_local_si_gana, 0)} si gana · "
              f"{pct(r.top6_local_si_pierde, 0)} si pierde")
        print(f"     {r.visitante}: top 6 {pct(r.top6_visit_si_gana, 0)} si gana · "
              f"{pct(r.top6_visit_si_pierde, 0)} si pierde")
        if r.tercero_delta_top6 >= .01:
            print(f"     Al {r.tercero_mas_afectado} le conviene que gane el "
                  f"{r.tercero_le_conviene} ({pct(r.tercero_delta_top6, 0)} de diferencia)")
    return c


def grafico_partidos_clave(c, jornada_prox, cfg=CONFIG):
    if c.empty:
        return None
    c = c.head(cfg.get("n_partidos_clave", 6))
    fig, ax = plt.subplots(figsize=(11, 1.25 * len(c) + 1.2))
    y = 0; ticks, labels = [], []
    for r in c.itertuples():
        for eq, act, sg, sp, prob, col in [
                (r.local, r.top6_local_actual, r.top6_local_si_gana, r.top6_local_si_pierde,
                 r.p_local, "#1c7ed6"),
                (r.visitante, r.top6_visit_actual, r.top6_visit_si_gana, r.top6_visit_si_pierde,
                 1 - r.p_local, "#f76707")]:
            ax.plot([sp * 100, sg * 100], [y, y], color=col, lw=3, alpha=.35,
                    solid_capstyle="round")
            ax.plot(sp * 100, y, "o", color="white", mec=col, mew=2, ms=8)
            ax.plot(sg * 100, y, "o", color=col, ms=8)
            ax.plot(act * 100, y, "|", color="#212529", ms=13, mew=2)
            if abs(sg - act) >= .01:
                ax.text(sg * 100 + (1.5 if sg >= sp else -1.5), y,
                        f"+{(sg - act) * 100:.0f}".replace("+-", "-"),
                        va="center", ha="left" if sg >= sp else "right", fontsize=8, color=col)
            if abs(sp - act) >= .01:
                ax.text(sp * 100 + (-1.5 if sg >= sp else 1.5), y,
                        f"{(sp - act) * 100:.0f}", va="center",
                        ha="right" if sg >= sp else "left", fontsize=8, color="#868e96")
            ticks.append(y); labels.append(f"{eq}  ({pct(prob, 0)})")
            y -= 1
        if r.tercero_delta_top6 >= .01:
            ax.text(106, y + 1.5, f"Al {r.tercero_mas_afectado} le\nconviene que gane\n"
                                  f"el {r.tercero_le_conviene}", fontsize=7.5,
                    color="#868e96", va="center")
        ax.axhline(y + .5, color="#e9ecef", lw=1)
        y -= .4
    ax.set_yticks(ticks, labels, fontsize=9)
    ax.set_xlim(-2, 104)
    ax.set_ylim(y + .2, .8)
    ax.set_xticks(range(0, 101, 20))
    ax.set_xlabel("Probabilidad de acabar en el top 6 (%)")
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.tick_params(axis="y", length=0)
    ax.set_title(f"Partidos clave · Jornada {jornada_prox}\n"
                 "● si gana   ○ si pierde   | ahora   (entre paréntesis: prob. de ganar el partido)",
                 fontsize=11)
    return _guardar(fig, f"partidos_clave_j{jornada_prox:02d}.png", cfg)


# ---------------------------------------------------------------------------
# 7. OPTIMIZACIÓN DE PARÁMETROS
# ---------------------------------------------------------------------------
import itertools
import json

ARCHIVO_PARAMETROS = "parametros_optimos.json"

# Valores que se prueban (todas las combinaciones)
REJILLA = {
    "regresion_previa": [0.4, 0.55, 0.7, 0.85],   # qué se conserva del año pasado
    "sd_previa": [3.0, 4.5, 6.0, 8.0],             # confianza en ese punto de partida
    "margen_max": [20, 25, 30, 40],                # recorte de palizas
    "vida_media": [None, 8, 15, 30],               # None = todos los partidos pesan igual
    "sd_hca_equipo": [0.0, 1.0, 2.0],              # 0 = misma ventaja de campo para todos
}


def _brier(p, y):
    return float(np.mean((np.asarray(p) - np.asarray(y)) ** 2))


def optimizar_parametros(df, df_prev, df_prev2, cfg):
    """Busca la combinación de parámetros con menos error en el backtest.
    Se ajusta con una temporada y se COMPRUEBA con otra distinta, para no
    engañarnos a nosotros mismos (sobreajuste)."""
    if df_prev is None:
        print("Hace falta al menos la temporada anterior para optimizar.")
        return None

    if df_prev2 is not None:
        ajuste_df, ajuste_previa = df_prev, df_prev2
        comprobacion = (df, df_prev)
        print(f"Ajuste con la temporada {cfg['temporada'] - 1}; "
              f"comprobación con la {cfg['temporada']}")
    else:
        ajuste_df, ajuste_previa = df, df_prev
        comprobacion = None
        print("AVISO: sin la temporada de hace dos años solo puedo ajustar con la "
              "actual, y no hay comprobación independiente (riesgo de sobreajuste).")

    def preparar(d, d_previa):
        A = _arrays_temporada(d)
        prev, sigma = ratings_temporada(d_previa, cfg)
        return A, prev, sigma

    A, prev, sigma = preparar(ajuste_df, ajuste_previa)
    y = (A["margen"] > 0).astype(int)

    claves = list(REJILLA)
    combos = list(itertools.product(*REJILLA.values()))
    print(f"Probando {len(combos)} combinaciones de parámetros...")
    filas = []
    for i, valores in enumerate(combos):
        c = dict(cfg, **dict(zip(claves, valores)), ajustes_prior={})
        mp, sp = prior_desde(A["equipos"], prev, c)
        p, _ = _predicciones_backtest(A, mp, sp, sigma, c)
        filas.append({**dict(zip(claves, valores)), "brier": _brier(p, y),
                      "acierto": float(np.mean((p > .5) == y))})
        if (i + 1) % 100 == 0:
            print(f"  {i + 1} / {len(combos)}", end="\r")
    print()
    res = pd.DataFrame(filas).sort_values("brier").reset_index(drop=True)
    res.to_csv(os.path.join(CARPETA_SALIDA, "optimizacion_rejilla.csv"), index=False)

    mejor = {k: (None if pd.isna(res.loc[0, k]) else res.loc[0, k]) for k in claves}
    mejor = {k: (v.item() if hasattr(v, "item") else v) for k, v in mejor.items()}

    print("\nLas 5 mejores combinaciones (temporada de ajuste):")
    vista = res.head(5).copy()
    vista["vida_media"] = vista["vida_media"].map(lambda v: "no" if pd.isna(v) else int(v))
    print(vista.to_string(index=False))
    # si el mejor valor está en un extremo de la rejilla, quizá convenga ampliarla
    for k in claves:
        opciones = [v for v in REJILLA[k] if v is not None]
        if mejor[k] and len(opciones) > 1 and mejor[k] in (min(opciones), max(opciones)):
            print(f"  Nota: '{k}' = {mejor[k]} está en el borde de la rejilla; "
                  f"puedes probar valores más allá en REJILLA")

    def evaluar(d, d_previa, c):
        Ae, pv, sg = preparar(d, d_previa)
        mp, sp = prior_desde(Ae["equipos"], pv, dict(c, ajustes_prior={}))
        p, _ = _predicciones_backtest(Ae, mp, sp, sg, c)
        ye = (Ae["margen"] > 0).astype(int)
        return {"brier": _brier(p, ye), "acierto": float(np.mean((p > .5) == ye)),
                "local_brier": _brier(np.full(len(ye), ye.mean()), ye),
                "local_acierto": float(ye.mean()), "partidos": len(ye)}

    cfg_v1 = dict(cfg, **{k: CONFIG_V1[k] for k in claves})
    cfg_v2 = dict(cfg, **mejor)
    informe = {"fecha": datetime.now().strftime("%Y-%m-%d %H:%M"), "parametros": mejor}
    tramos = [("ajuste", ajuste_df, ajuste_previa)]
    if comprobacion:
        tramos.append(("comprobacion", *comprobacion))
    print("\nCOMPARACIÓN (Brier: más bajo = mejor)")
    for nombre, d, dp in tramos:
        e1, e2 = evaluar(d, dp, cfg_v1), evaluar(d, dp, cfg_v2)
        informe[nombre] = {"v1": e1, "v2": e2}
        etiqueta = "Temporada de ajuste" if nombre == "ajuste" else "Comprobación (no vista)"
        print(f"  {etiqueta} · {e1['partidos']} partidos")
        for lab, b, a in [("Siempre gana el local", e1["local_brier"], e1["local_acierto"]),
                          ("Modelo v1", e1["brier"], e1["acierto"]),
                          ("Modelo v2", e2["brier"], e2["acierto"])]:
            print(f"     {lab:22s} Brier {b:.4f}".replace(".", ",") + f" · acierto {pct(a)}")

    with open(os.path.join(CARPETA_SALIDA, ARCHIVO_PARAMETROS), "w") as f:
        json.dump(informe, f, indent=2, ensure_ascii=False)
    print(f"\nParámetros guardados en {CARPETA_SALIDA}/{ARCHIVO_PARAMETROS}:")
    for k, v in mejor.items():
        print(f"   {k} = {v}")
    return mejor


def cargar_parametros_optimos(cfg):
    ruta = os.path.join(CARPETA_SALIDA, ARCHIVO_PARAMETROS)
    if not os.path.exists(ruta):
        print("(No hay parámetros optimizados todavía; uso los de CONFIG)")
        return cfg
    with open(ruta) as f:
        params = json.load(f)["parametros"]
    print(f"Usando parámetros optimizados: {params}")
    return dict(cfg, **params)


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="Simulador Montecarlo de la Euroliga")
    ap.add_argument("--temporada", type=int, default=CONFIG["temporada"])
    ap.add_argument("--sims", type=int, default=CONFIG["n_sims"])
    ap.add_argument("--csv", help="CSV con los partidos de la temporada actual")
    ap.add_argument("--csv-previa", help="CSV con los partidos de la temporada anterior")
    ap.add_argument("--sin-previa", action="store_true",
                    help="No usar la temporada anterior como punto de partida")
    ap.add_argument("--demo", action="store_true", help="Liga inventada para probar")
    ap.add_argument("--semilla", type=int, default=CONFIG["semilla"])
    ap.add_argument("--optimizar", action="store_true",
                    help="Busca los mejores parámetros con el backtest y los guarda")
    ap.add_argument("--sin-optimos", action="store_true",
                    help="Ignora los parámetros optimizados y usa los de CONFIG")
    args = ap.parse_args()

    cfg = dict(CONFIG, temporada=args.temporada, n_sims=args.sims)
    rng = np.random.default_rng(args.semilla)
    os.makedirs(CARPETA_SALIDA, exist_ok=True)

    # --- datos
    if args.demo:
        print("MODO DEMO: equipos y resultados inventados")
        df, df_prev, df_prev2 = datos_demo(rng)
    else:
        try:
            df = cargar_datos(cfg["temporada"], args.csv)
        except Exception as e:
            raise SystemExit(f"No he podido cargar los datos ({e}).\n"
                             "Prueba con --csv partidos.csv o con --demo")
        df_prev = None
        if not args.sin_previa:
            try:
                df_prev = cargar_datos(cfg["temporada"] - 1, args.csv_previa)
            except Exception as e:
                print(f"No se pudo cargar la temporada anterior ({e}); sigo sin prior")
        # la de hace dos años solo sirve para validar bien la temporada pasada
        df_prev2 = None
        if df_prev is not None:
            try:
                df_prev2 = cargar_datos(cfg["temporada"] - 2)
            except Exception as e:
                print(f"(Sin temporada de hace dos años: {e})")

    comprobar_calendario(df)

    # --- parámetros (v2): optimizar si se pide y usar los óptimos guardados
    if args.optimizar:
        optimizar_parametros(df, df_prev, df_prev2, cfg)
    if not args.sin_optimos:
        cfg = cargar_parametros_optimos(cfg)

    equipos = sorted(set(df.cod_local) | set(df.cod_visitante))
    nombres = {**dict(zip(df.cod_visitante, df.visitante)),
               **dict(zip(df.cod_local, df.local))}
    jug = df[df.pts_local.notna()]
    jornada = int(jug.jornada.max()) if len(jug) else 0

    # --- ratings
    m_prior, sd_prior, sigma = construir_prior(equipos, df_prev, cfg)
    media, cov, _, _ = ajustar_ratings(df, equipos, m_prior, sd_prior, sigma, cfg)
    print(f"Ventaja de campo media estimada: {media[len(equipos)]:.1f} puntos")

    # --- simulación
    print(f"Simulando {num(cfg['n_sims'])} temporadas...")
    pendientes = df.pts_local.isna().values
    jornada_prox = int(df.jornada[pendientes].min()) if pendientes.any() else None
    idx_clave = (np.where(pendientes & (df.jornada.values == jornada_prox))[0]
                 if jornada_prox else np.array([], int))
    acc = simular(df, equipos, media, cov, sigma, cfg, rng, idx_clave)

    # --- resultados
    t = tabla_resumen(df, equipos, nombres, media, acc, cfg)
    ruta = os.path.join(CARPETA_SALIDA, f"resumen_j{jornada:02d}.csv")
    t.to_csv(ruta, index=False)

    pd.set_option("display.width", 200)
    vista = t[["equipo", "V", "D", "rating", "victorias_esperadas", "p_top6",
               "p_playin", "p_final_four", "p_campeon"]].copy()
    for c in ["p_top6", "p_playin", "p_final_four", "p_campeon"]:
        vista[c] = vista[c].map(pct)
    print("\n" + vista.to_string(index=False))

    curiosidad_victorias(acc, cfg)

    rutas = [ruta,
             grafico_mapa_posiciones(t, equipos, acc, cfg, jornada),
             grafico_destinos(t, cfg, jornada),
             grafico_victorias(t, equipos, acc, jornada, cfg),
             grafico_campeon(t, jornada, cfg),
             actualizar_historial(t, jornada, cfg)]

    # --- partidos clave de la próxima jornada
    if jornada_prox:
        clave = analizar_partidos_clave(df, idx_clave, equipos, nombres, media, cov,
                                        sigma, acc, cfg)
        r_clave = os.path.join(CARPETA_SALIDA, f"partidos_clave_j{jornada_prox:02d}.csv")
        clave.to_csv(r_clave, index=False)
        rutas += [r_clave, grafico_partidos_clave(clave, jornada_prox, cfg),
                  registrar_predicciones(clave, cfg["temporada"], df),
                  plantilla_cuotas(clave, jornada_prox)]

    # --- validación (backtest de esta temporada y, si hay datos, de la pasada)
    bt = backtest(df, m_prior, sd_prior, sigma, cfg, cfg["temporada"])
    if df_prev is not None:
        eq_prev = sorted(set(df_prev.cod_local) | set(df_prev.cod_visitante))
        cfg_prev = dict(cfg, ajustes_prior={})
        print("Backtest de la temporada pasada:", end=" ")
        mp, sp, sg = construir_prior(eq_prev, df_prev2, cfg_prev)
        bt = pd.concat([bt, backtest(df_prev, mp, sp, sg, cfg_prev, cfg["temporada"] - 1)],
                       ignore_index=True)
    rutas.append(validar(bt, cfg["temporada"], jornada, cfg))
    print("\nArchivos generados:")
    for r in rutas:
        if r: print("  ", r)


if __name__ == "__main__":
    main()
